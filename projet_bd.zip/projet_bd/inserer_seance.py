# inserer_seance.py
import streamlit as st
import requests

def inserer_seance(IDS, NOM, TYPE, NIVEAU):
    url = 'https://apex.oracle.com/pls/apex/mery/seance/'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
        'Content-Type': 'application/json',
    }

    data = {
        "IDS": IDS,
        "NOM": NOM,
        "TYPE": TYPE,
        "NIVEAU": NIVEAU
    }

    try:
        response = requests.post(url, json=data, headers=headers)
        response.raise_for_status()
        seance_data = response.json()

        if "IDS" in seance_data:
            st.success("Séance insérée avec succès!")
        else:
            st.error(f"Erreur lors de l'insertion de la séance. Détails de la réponse : {seance_data}")
    except requests.exceptions.RequestException as e:
        st.error(f"Erreur de requête : {e}")

# Page principale de l'insertion
def inserer_seance_page():
    st.title("Formulaire d'Insertion de Séance")

    # Formulaire de saisie pour la nouvelle séance
    IDS = st.number_input("ID de la séance", min_value=1)
    NOM = st.text_input("Nom de la séance")
    TYPE = st.text_input("Type de la séance")
    NIVEAU = st.text_input("Niveau de la séance")

    # Bouton pour l'insertion de la séance
    if st.button("Insérer la Séance"):
        # Vérification des champs
        if IDS and NOM and TYPE and NIVEAU:
            # Appel de la fonction d'insertion
            inserer_seance(IDS, NOM, TYPE, NIVEAU)
        else:
            st.warning("Veuillez remplir tous les champs du formulaire.")
